﻿using System;
namespace ConsoleApp
{
	//Sokak 
	internal class Sokak
	{
		int enBuyukSayi = 100;
	
		//Okul 
		void okul() 
		{
			int ortancaSayi = 50;
			
			//Sınıf
			if(ortancaSayi > 0)
            {
                int enKucukSayi = 20;
            }

        }   
		    
	}

    //enBuyukSayi 6 - 22
    //ortancaSayi 11 - 20
    //enKucukSayi 16 - 18
}
