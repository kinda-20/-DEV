﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Deger Giriniz!");

//double deger1 = Convert. ToDouble(Console.ReadLine ( ));

DateTime deger1 = Convert.ToDateTime (Console.ReadLine());

Console.WriteLine("Sayi bir degerimiz: " + deger1.ToString()); 