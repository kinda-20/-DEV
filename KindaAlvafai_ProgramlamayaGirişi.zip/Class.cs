﻿using System;
namespace Application
{
	public class Class
	{
		public Class()
		{
		}
	}
}

