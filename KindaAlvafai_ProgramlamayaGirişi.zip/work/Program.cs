﻿Console.WriteLine("adınız giri");
string kullanİcİAdi = Console.ReadLine();

Console.WriteLine("sifre");
string sifre = Console.ReadLine();

if(kullanİcİAdi == "Admin" & sifre == "123")
{
    Console.WriteLine("Tebrikler giris başarli");
}
else
{
    Console.WriteLine("giriş başarsız");
}