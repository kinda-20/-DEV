﻿using System;
namespace sure
{
	public class EmptyClass
	{
		public EmptyClass()
		{
		}
	}
}

