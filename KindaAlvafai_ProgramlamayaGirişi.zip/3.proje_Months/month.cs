﻿byte Ay = Convert.ToByte(Console.ReadLine());
switch (Ay)
{
    case 1:
        Console.WriteLine("Ocak");
        break;
    case 2:
        Console.WriteLine("Şubat");
        break;
    case 3:
        Console.WriteLine("Mart");
        break;
    case 4:
        Console.WriteLine("Nisan");
        break;
    case 5:
        Console.WriteLine("Mayıs");
        break;
    case 6:
        Console.WriteLine("Haziran");
        break;
    case 7:
        Console.WriteLine("Temmuz");
        break;
    case 8:
        Console.WriteLine("Ağustos");
        break;
    case 9:
        Console.WriteLine("Eylül");
        break;
    case 10:
        Console.WriteLine("Ekim");
        break;
    case 11:
        Console.WriteLine("Kasım");
        break;
    case 12:
        Console.WriteLine("Aralık");
        break;
}



if(Ay == 1)
{
    Console.WriteLine("Ocak");
} else if (Ay == 2)
{
    Console.WriteLine("Şubat");
} else if (Ay == 3)
{
    Console.WriteLine("Mart");
} else if (Ay == 4)
{
    Console.WriteLine("Nisan");
} else if (Ay == 5)
{
    Console.WriteLine("Mayıs");
} else if (Ay == 6)
{
    Console.WriteLine("Haziran");
} else if (Ay == 7)
{
    Console.WriteLine("Temmuz");
} else if (Ay == 8)
{
    Console.WriteLine("Ağustos");
} else if (Ay == 9)
{
    Console.WriteLine("Eylül");
} else if (Ay == 10)
{
    Console.WriteLine("Ekim");
} else if (Ay == 11)
{
    Console.WriteLine("Kasım");
} else if (Ay == 12)
{
    Console.WriteLine("Aralık");
} else
{
    Console.WriteLine("The year have 12 month");
}